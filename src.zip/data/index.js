export default {

Content:[
	{content_id:1,
	 user_id:1,
	 user_name:'홍길동',
	 title:'강의알림표1',
	 context:'미정',
	 created_at:'2020-07-20 09:09:10',
	 update_at:null},
	
	 {content_id:2,
      user_id:2,
	 user_name:'김길호',
	 title:'강의알림표2',
	 context:'미정',
	 created_at:'2020-07-20 09:09:10',
	 update_at:null},
	
	 {content_id:3,
	  user_id:3,
	 user_name:'이민호',
	 title:'강의알림표3',
	 context:'미정',
	 created_at:'2020-07-20 09:09:10',
	 update_at:null}
 ]

}